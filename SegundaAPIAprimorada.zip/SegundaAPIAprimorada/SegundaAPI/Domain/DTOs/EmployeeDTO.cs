﻿namespace SegundaAPI.Domain.DTOs
{
    public class EmployeeDTO
    {
        public int Id { get; set; }
        public string NameEmployee { get; set; }
        public string? Photo { get; set; }
    }
}
