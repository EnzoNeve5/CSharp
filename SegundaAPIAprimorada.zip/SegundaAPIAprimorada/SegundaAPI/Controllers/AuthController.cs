﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using SegundaAPI.Application.Services;
using SegundaAPI.Domain.Model.EmployeeAggregate;

namespace SegundaAPI.Controllers
{
    [ApiController]
    [Route("api/v1/auth")]
    public class AuthController : Controller
    {
        [HttpPost]
        public IActionResult Auth(string username, string password)
        {
            if (username == "enzoneves" && password == "12345678")
            {
                // Provide required arguments for the Employee constructor  
                var token = TokenService.GenerateToken(new Employee("filipe", 30, null));
                return Ok(token);
            }
            return BadRequest("Invalid username or password");
        }
    }
}
