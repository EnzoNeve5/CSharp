﻿namespace SegundaAPI
{
    public class Key
    {
        public static string Secret = "12345678901234567890123456789012";
    }
}
